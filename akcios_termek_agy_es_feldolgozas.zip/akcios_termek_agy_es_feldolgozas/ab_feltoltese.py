import re
import csv
import pyodbc
from pathlib import Path
from decimal import Decimal, InvalidOperation

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"

FIX_ALAP_ADATOK = OUTPUT_DIR / "fix_alap_adatok.csv"
KATEGORIA_HIERARCHIA = OUTPUT_DIR / "kategoria_hierarchia.txt"
KEDVEZMENY_TIPUSOK = OUTPUT_DIR / "kedvezmeny_tipusok.csv"
TULAJDONSAGOK = OUTPUT_DIR / "tulajdonsagok.csv"
KISZERELESEK = OUTPUT_DIR / "kiszerelesek.csv"

CONNECTION_STRING = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=ASRIEL\\SQLEXPRESS;"
    "DATABASE=akcios_termekek_db;"
    "Trusted_Connection=yes;"
)

def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def is_valid_tulajdonsag(value):
    if not value:
        return False

    value = value.strip()
    lower = value.lower()

    # : 1014Ft jellegű
    if re.fullmatch(r":\s*\d+\s*Ft", value, re.IGNORECASE):
        return False

    # sima ár
    if re.fullmatch(r"\d+\s*Ft", value, re.IGNORECASE):
        return False

    # összetett ár: pl. 279Ft/1 cs 655Ft/3 cs
    if re.search(r"\d+\s*Ft.*\d+\s*Ft", value, re.IGNORECASE):
        return False

    # csak számok / jelek
    if re.fullmatch(r"[\d\s/%.,-]+", value):
        return False

    # csak szám (maradék cikk)
    if re.fullmatch(r"\d+/", value):
        return False

    # technikai/zaj szövegek
    zaj_mintak = [
        "ajánlatunk a készlet",
        "a feltüntetett ár",
        "előírás",
        "esetén:",
    ]
    if any(minta in lower for minta in zaj_mintak):
        return False

    return True

def unique_by_hash(rows):
    seen = set()
    result = []

    for row in rows:
        hash_value = row.get("egyedi_hash", "").strip()

        if not hash_value or hash_value in seen:
            continue

        seen.add(hash_value)
        result.append(row)

    return result


def insert_kategoriak(cursor):
    rows = read_csv(KATEGORIA_HIERARCHIA)
    last_by_level = {}

    for row in rows:
        nev = row["kategórianév"].strip()
        szint = int(row["hierarchiaszint"])

        szulo_id = None
        if szint > 1:
            szulo_id = last_by_level.get(szint - 1)

        cursor.execute(
            """
            IF NOT EXISTS (SELECT 1 FROM dbo.Kategoria WHERE nev = ?)
            BEGIN
                INSERT INTO dbo.Kategoria (nev, szulo_azonosito)
                VALUES (?, ?)
            END
            """,
            nev, nev, szulo_id
        )

        cursor.execute(
            "SELECT azonosito FROM dbo.Kategoria WHERE nev = ?",
            nev
        )
        last_by_level[szint] = cursor.fetchone()[0]


def insert_uzletlancok(cursor, alap_rows):
    boltok = sorted({
        row["bolt_neve"].strip()
        for row in alap_rows
        if row.get("bolt_neve", "").strip()
    })

    for bolt in boltok:
        cursor.execute(
            """
            IF NOT EXISTS (SELECT 1 FROM dbo.Uzletlanc WHERE nev = ?)
            BEGIN
                INSERT INTO dbo.Uzletlanc (nev)
                VALUES (?)
            END
            """,
            bolt, bolt
        )


def insert_kedvezmeny_tipusok(cursor):
    # Alap típus a sima akciókra
    cursor.execute(
        """
        IF NOT EXISTS (
            SELECT 1 FROM dbo.Kedvezmeny_Tipus
            WHERE tipus = ? AND ISNULL(leiras, '') = ISNULL(?, '')
        )
        BEGIN
            INSERT INTO dbo.Kedvezmeny_Tipus (tipus, leiras)
            VALUES (?, ?)
        END
        """,
        "normál akció",
        "Egyszerű akciós ár, külön feltétel nélkül.",
        "normál akció",
        "Egyszerű akciós ár, külön feltétel nélkül."
    )

    rows = read_csv(KEDVEZMENY_TIPUSOK)
    seen = set()

    for row in rows:
        leiras = row.get("ertek", "").strip()

        if not leiras:
            continue

        # A CSV-ben most csak ertek van, ezért típust általánosan adunk.
        tipus = "összetett akció"

        key = (tipus, leiras)
        if key in seen:
            continue
        seen.add(key)

        cursor.execute(
            """
            IF NOT EXISTS (
                SELECT 1 FROM dbo.Kedvezmeny_Tipus
                WHERE tipus = ? AND ISNULL(leiras, '') = ISNULL(?, '')
            )
            BEGIN
                INSERT INTO dbo.Kedvezmeny_Tipus (tipus, leiras)
                VALUES (?, ?)
            END
            """,
            tipus, leiras, tipus, leiras
        )


def insert_cikkek(cursor, alap_rows):
    seen_cikk = set()

    for row in alap_rows:
        termek_nev = row["termek_neve"].strip()
        kategoria_nev = row["kategoria"].strip()

        if not termek_nev or termek_nev in seen_cikk:
            continue

        cursor.execute(
            "SELECT azonosito FROM dbo.Kategoria WHERE nev = ?",
            kategoria_nev
        )
        result = cursor.fetchone()

        if result is None:
            print(f"Hiányzó kategória, cikk kihagyva: {kategoria_nev} | {termek_nev}")
            continue

        kategoria_id = result[0]

        cursor.execute(
            """
            IF NOT EXISTS (SELECT 1 FROM dbo.Cikk WHERE nev = ?)
            BEGIN
                INSERT INTO dbo.Cikk (nev, kategoria_azonosito)
                VALUES (?, ?)
            END
            """,
            termek_nev, termek_nev, kategoria_id
        )

        seen_cikk.add(termek_nev)


def insert_tulajdonsagok(cursor):
    rows = read_csv(TULAJDONSAGOK)
    seen = set()

    for row in rows:
        ertek = row.get("ertek", "").strip()

        if not is_valid_tulajdonsag(ertek):
            continue

        if ertek in seen:
            continue

        seen.add(ertek)

        cursor.execute(
            """
            IF NOT EXISTS (SELECT 1 FROM dbo.Tulajdonsag WHERE nev = ?)
            BEGIN
                INSERT INTO dbo.Tulajdonsag (nev)
                VALUES (?)
            END
            """,
            ertek, ertek
        )


def insert_cikk_es_tulajdonsag(cursor, alap_rows):
    tulajdonsag_rows = read_csv(TULAJDONSAGOK)

    hash_to_cikknev = {}

    for row in alap_rows:
        egyedi_hash = row.get("egyedi_hash", "").strip()
        termek_nev = row.get("termek_neve", "").strip()

        if egyedi_hash and termek_nev:
            hash_to_cikknev[egyedi_hash] = termek_nev

    inserted_pairs = set()

    for row in tulajdonsag_rows:
        egyedi_hash = row.get("egyedi_hash", "").strip()
        tulajdonsag_ertek = row.get("ertek", "").strip()

        if not egyedi_hash or not tulajdonsag_ertek:
            continue

        if not is_valid_tulajdonsag(tulajdonsag_ertek):
            continue

        cikk_nev = hash_to_cikknev.get(egyedi_hash)

        if not cikk_nev:
            continue

        cursor.execute(
            "SELECT azonosito FROM dbo.Cikk WHERE nev = ?",
            cikk_nev
        )
        cikk_result = cursor.fetchone()

        if cikk_result is None:
            continue

        cikk_id = cikk_result[0]

        cursor.execute(
            "SELECT azonosito FROM dbo.Tulajdonsag WHERE nev = ?",
            tulajdonsag_ertek
        )
        tulajdonsag_result = cursor.fetchone()

        if tulajdonsag_result is None:
            continue

        tulajdonsag_id = tulajdonsag_result[0]

        pair = (cikk_id, tulajdonsag_id)

        if pair in inserted_pairs:
            continue

        inserted_pairs.add(pair)

        cursor.execute(
            """
            IF NOT EXISTS (
                SELECT 1
                FROM dbo.Cikk_Es_Tulajdonsag
                WHERE cikk_azonosito = ?
                  AND tulajdonsag_azonosito = ?
            )
            BEGIN
                INSERT INTO dbo.Cikk_Es_Tulajdonsag
                    (cikk_azonosito, tulajdonsag_azonosito)
                VALUES (?, ?)
            END
            """,
            cikk_id, tulajdonsag_id,
            cikk_id, tulajdonsag_id
        )


from decimal import Decimal, InvalidOperation

def to_decimal_or_none(value):
    value = (value or "").strip().replace(",", ".")

    if not value:
        return None

    try:
        return Decimal(value)
    except InvalidOperation:
        return None


def to_int_or_default(value, default=1):
    value = (value or "").strip()

    if not value:
        return default

    try:
        return int(value)
    except ValueError:
        return default


def insert_kiszerelesek(cursor, alap_rows):
    kiszereles_rows = read_csv(KISZERELESEK)

    # hash → cikk név
    hash_to_cikknev = {}
    for row in alap_rows:
        egyedi_hash = row.get("egyedi_hash", "").strip()
        termek_nev = row.get("termek_neve", "").strip()

        if egyedi_hash and termek_nev:
            hash_to_cikknev[egyedi_hash] = termek_nev

    inserted = set()

    for row in kiszereles_rows:
        egyedi_hash = row.get("egyedi_hash", "").strip()

        egyseg = to_decimal_or_none(row.get("ertek"))
        mertekegyseg = (row.get("egyseg") or "").strip().lower() or None
        darabszam = to_int_or_default(row.get("darabszam"), 1)

        # alap validációk
        if not egyedi_hash:
            continue

        if mertekegyseg not in ("kg", "l", "db", None):
            continue

        if darabszam <= 0:
            continue

        # cikk meghatározása
        cikk_nev = hash_to_cikknev.get(egyedi_hash)
        if not cikk_nev:
            continue

        cursor.execute(
            "SELECT azonosito FROM dbo.Cikk WHERE nev = ?",
            cikk_nev
        )
        result = cursor.fetchone()

        if result is None:
            continue

        cikk_id = result[0]

        # duplikáció ellenőrzés Python oldalon
        key = (cikk_id, str(egyseg), mertekegyseg, darabszam)

        if key in inserted:
            continue

        inserted.add(key)

        # 🔥 BESZÚRÁS HIBAKEZELÉSSEL
        try:
            cursor.execute(
                """
                IF NOT EXISTS (
                    SELECT 1
                    FROM dbo.Kiszereles
                    WHERE cikk_azonosito = ?
                      AND ISNULL(egyseg, -1) = ISNULL(?, -1)
                      AND ISNULL(mertekegyseg, '') = ISNULL(?, '')
                      AND darabszam = ?
                )
                BEGIN
                    INSERT INTO dbo.Kiszereles
                        (cikk_azonosito, egyseg, mertekegyseg, darabszam)
                    VALUES (?, ?, ?, ?)
                END
                """,
                cikk_id, egyseg, mertekegyseg, darabszam,
                cikk_id, egyseg, mertekegyseg, darabszam
            )

        except pyodbc.IntegrityError:
            # ha mégis duplikáció → kihagyjuk
            continue


def insert_termekek(cursor, alap_rows):
    kiszereles_rows = read_csv(KISZERELESEK)

    # hash → cikk név
    hash_to_cikknev = {}
    for row in alap_rows:
        h = row.get("egyedi_hash", "").strip()
        nev = row.get("termek_neve", "").strip()
        if h and nev:
            hash_to_cikknev[h] = nev

    # hash → kiszerelés adatok
    hash_to_kiszereles = {}
    for row in kiszereles_rows:
        h = row.get("egyedi_hash", "").strip()
        egyseg = to_decimal_or_none(row.get("ertek"))
        mertekegyseg = (row.get("egyseg") or "").strip().lower() or None
        darabszam = to_int_or_default(row.get("darabszam"), 1)

        if h:
            hash_to_kiszereles[h] = (egyseg, mertekegyseg, darabszam)

    inserted = set()

    for row in alap_rows:
        h = row.get("egyedi_hash", "").strip()
        bolt = row.get("bolt_neve", "").strip()
        ar = row.get("eredeti_ar", "").replace("Ft", "").replace(" ", "").strip()

        if not h or not bolt or not ar:
            continue

        try:
            ar = int(ar)
        except:
            continue

        # 🔹 üzletlánc ID
        cursor.execute(
            "SELECT azonosito FROM dbo.Uzletlanc WHERE nev = ?",
            bolt
        )
        uzlet = cursor.fetchone()
        if not uzlet:
            continue

        uzlet_id = uzlet[0]

        # 🔹 cikk ID
        cikk_nev = hash_to_cikknev.get(h)
        if not cikk_nev:
            continue

        cursor.execute(
            "SELECT azonosito FROM dbo.Cikk WHERE nev = ?",
            cikk_nev
        )
        cikk = cursor.fetchone()
        if not cikk:
            continue

        cikk_id = cikk[0]

        # 🔹 kiszerelés ID
        kisz = hash_to_kiszereles.get(h)
        if not kisz:
            continue

        egyseg, mertekegyseg, darabszam = kisz

        cursor.execute(
            """
            SELECT azonosito FROM dbo.Kiszereles
            WHERE cikk_azonosito = ?
              AND ISNULL(egyseg, -1) = ISNULL(?, -1)
              AND ISNULL(mertekegyseg, '') = ISNULL(?, '')
              AND darabszam = ?
            """,
            cikk_id, egyseg, mertekegyseg, darabszam
        )
        kisz_res = cursor.fetchone()
        if not kisz_res:
            continue

        kisz_id = kisz_res[0]

        key = (uzlet_id, kisz_id)

        if key in inserted:
            continue

        inserted.add(key)

        cursor.execute(
            """
            IF NOT EXISTS (
                SELECT 1 FROM dbo.Termek
                WHERE uzletlanc_azonosito = ?
                  AND kiszereles_azonosito = ?
            )
            BEGIN
                INSERT INTO dbo.Termek
                    (uzletlanc_azonosito, kiszereles_azonosito)
                VALUES (?, ?)
            END
            """,
            uzlet_id, kisz_id,
            uzlet_id, kisz_id
        )

        cursor.execute(
            """
            SELECT azonosito
            FROM dbo.Termek
            WHERE uzletlanc_azonosito = ?
              AND kiszereles_azonosito = ?
            """,
            uzlet_id, kisz_id
        )
        termek_result = cursor.fetchone()

        if termek_result is None:
            continue

        termek_id = termek_result[0]

        # Az eredeti ar az aktualis_ar_naplo tablaba kerul.
        # Az eljaras csak akkor szur be uj sort, ha meg nincs ar, vagy valtozott az ar.
        cursor.execute(
            "EXEC dbo.SP_aktualis_ar_modositasa @termek_azonosito = ?, @uj_ar = ?",
            termek_id,
            ar
        )


def insert_kedvezmenyek(cursor, alap_rows):
    kiszereles_rows = read_csv(KISZERELESEK)
    tipus_rows = read_csv(KEDVEZMENY_TIPUSOK)

    # hash -> kedvezmény típus leírás
    hash_to_tipus_leiras = {}

    for row in tipus_rows:
        h = row.get("egyedi_hash", "").strip()
        leiras = row.get("ertek", "").strip()

        if h and leiras and h not in hash_to_tipus_leiras:
            hash_to_tipus_leiras[h] = leiras

    # hash -> kiszerelés adatok
    hash_to_kiszereles = {}

    for row in kiszereles_rows:
        h = row.get("egyedi_hash", "").strip()
        egyseg = to_decimal_or_none(row.get("ertek"))
        mertekegyseg = (row.get("egyseg") or "").strip().lower() or None
        darabszam = to_int_or_default(row.get("darabszam"), 1)

        if h:
            hash_to_kiszereles[h] = (egyseg, mertekegyseg, darabszam)

    for row in alap_rows:
        h = row.get("egyedi_hash", "").strip()
        bolt_nev = row.get("bolt_neve", "").strip()
        cikk_nev = row.get("termek_neve", "").strip()

        kedvezmenyes_ar = row.get("kedvezmenyes_ar", "").strip()
        kartyas_ertek = row.get("kartyas_e", "").strip()
        datum_tol = row.get("kezdeti_datum", "").strip()
        datum_ig = row.get("vege_datum", "").strip()

        if not h or not bolt_nev or not cikk_nev:
            continue

        if not kedvezmenyes_ar or not datum_tol or not datum_ig:
            continue

        kedvezmenyes_ar = int(kedvezmenyes_ar)
        kartyas = 1 if kartyas_ertek == "True" else 0

        if kedvezmenyes_ar <= 0:
            continue

        # üzletlánc
        cursor.execute(
            "SELECT azonosito FROM dbo.uzletlanc WHERE nev = ?",
            bolt_nev
        )
        uzlet_result = cursor.fetchone()

        if uzlet_result is None:
            continue

        uzlet_id = uzlet_result[0]

        # cikk
        cursor.execute(
            "SELECT azonosito FROM dbo.cikk WHERE nev = ?",
            cikk_nev
        )
        cikk_result = cursor.fetchone()

        if cikk_result is None:
            continue

        cikk_id = cikk_result[0]

        # kiszerelés
        kiszereles_adat = hash_to_kiszereles.get(h)

        if not kiszereles_adat:
            continue

        egyseg, mertekegyseg, darabszam = kiszereles_adat

        cursor.execute(
            """
            SELECT azonosito
            FROM dbo.kiszereles
            WHERE cikk_azonosito = ?
              AND ISNULL(egyseg, -1) = ISNULL(?, -1)
              AND ISNULL(mertekegyseg, '') = ISNULL(?, '')
              AND darabszam = ?
            """,
            cikk_id, egyseg, mertekegyseg, darabszam
        )
        kiszereles_result = cursor.fetchone()

        if kiszereles_result is None:
            continue

        kiszereles_id = kiszereles_result[0]

        # termék
        cursor.execute(
            """
            SELECT azonosito
            FROM dbo.termek
            WHERE uzletlanc_azonosito = ?
              AND kiszereles_azonosito = ?
            """,
            uzlet_id, kiszereles_id
        )
        termek_result = cursor.fetchone()

        if termek_result is None:
            continue

        termek_id = termek_result[0]

        # kedvezmény típus
        tipus_leiras = hash_to_tipus_leiras.get(h)

        if tipus_leiras:
            tipus = "összetett akció"
        else:
            tipus = "normál akció"
            tipus_leiras = "Egyszerű akciós ár, külön feltétel nélkül."

        cursor.execute(
            """
            SELECT azonosito
            FROM dbo.kedvezmeny_tipus
            WHERE tipus = ?
              AND ISNULL(leiras, '') = ISNULL(?, '')
            """,
            tipus, tipus_leiras
        )
        tipus_result = cursor.fetchone()

        if tipus_result is None:
            continue

        kedvezmeny_tipus_id = tipus_result[0]
        megjegyzes = None

        try:
            cursor.execute(
                """
                IF NOT EXISTS (
                    SELECT 1
                    FROM dbo.kedvezmeny
                    WHERE termek_azonosito = ?
                      AND kedvezmeny_tipus_azonosito = ?
                      AND datum_tol = ?
                      AND datum_ig = ?
                )
                BEGIN
                    INSERT INTO dbo.kedvezmeny
                        (
                            termek_azonosito,
                            kedvezmeny_tipus_azonosito,
                            kedvezmenyes_ar,
                            kartyas,
                            datum_tol,
                            datum_ig
                        )
                    VALUES (?, ?, ?, ?, ?, ?)
                END
                """,
                termek_id, kedvezmeny_tipus_id, datum_tol, datum_ig,
                termek_id, kedvezmeny_tipus_id, kedvezmenyes_ar,
                kartyas, datum_tol, datum_ig
            )

        except pyodbc.IntegrityError:
            continue


def main():
    alap_rows_raw = read_csv(FIX_ALAP_ADATOK)
    alap_rows = unique_by_hash(alap_rows_raw)

    print(f"Eredeti fix_alap_adatok sorok: {len(alap_rows_raw)}")
    print(f"Egyedi hash alapján használt sorok: {len(alap_rows)}")

    conn = pyodbc.connect(CONNECTION_STRING)

    try:
        cursor = conn.cursor()

        insert_kategoriak(cursor)
        conn.commit()
        print("Kategóriák betöltve.")

        insert_uzletlancok(cursor, alap_rows)
        conn.commit()
        print("Üzletláncok betöltve.")

        insert_kedvezmeny_tipusok(cursor)
        conn.commit()
        print("Kedvezménytípusok betöltve.")

        insert_cikkek(cursor, alap_rows)
        conn.commit()
        print("Cikkek betöltve.")

        insert_tulajdonsagok(cursor)
        conn.commit()
        print("Tulajdonságok betöltve.")

        insert_cikk_es_tulajdonsag(cursor, alap_rows)
        conn.commit()
        print("Cikk és tulajdonság kapcsolatok betöltve.")

        insert_kiszerelesek(cursor, alap_rows)
        conn.commit()
        print("Kiszerelések betöltve.")

        insert_termekek(cursor, alap_rows)
        conn.commit()
        print("Termékek betöltve.")

        insert_kedvezmenyek(cursor, alap_rows)
        conn.commit()
        print("Kedvezmények betöltve.")

        print("Kész, minden mentve.")

    except pyodbc.IntegrityError as e:
        conn.rollback()
        print("Egyedi megszorításba ütköző adatot talált a program.")
        print("A már korábban sikeresen mentett táblák adatai megmaradtak.")
        print("Az aktuális művelet visszavonásra került.")
        print(e)

    except Exception as e:
        conn.rollback()
        print("Váratlan hiba történt.")
        print("Az aktuális művelet visszavonásra került.")
        print("A korábban commitolt adatok megmaradtak.")
        print(e)

    finally:
        conn.close()


if __name__ == "__main__":
    main()